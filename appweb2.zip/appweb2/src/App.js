import React from 'react';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import './App.css';

import { Login } from "./components/Login";
import { Register } from "./components/Register";
import { Navbar } from './components/Navbar';

import 'bootswatch/dist/slate/bootstrap.min.css'

function App() {
  return (
    <Router>
      <Navbar />
      <div>
        <Switch>
          <Route path="/register" component={Register}/>
          <Route path="/" component={Login}/>
        </Switch>
      </div>
    </Router>
  );
}

export default App;