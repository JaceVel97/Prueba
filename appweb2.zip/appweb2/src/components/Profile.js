import React from 'react'
import Button from 'react-bootstrap/Button';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl';

const name = window.$name;
const age = window.$age;
const birthplace = window.$birthplace;
const email = window.$email;

export const Profile = () => {
    const handleInsert = (e) => {
        window.$name = '';
        window.$age = '';
        window.$birthplace = '';
        window.$email = '';
    }
    return (
        <div className="container">
            <div className="row">
                <div className="mx-auto">
                    <h1 className="display-4">Bienvenido a esta App Web</h1>
                </div>
            </div>
            <div className="row">
                <div className="mx-auto">
                    <h3 className="display-8">Los datos mas sorprendentes e importantes son tu informacion</h3>
                </div>
            </div>
            <div className="row">
                <div className="mx-auto">
                    <h4 className="display-8">¡¡¡Tu eres importante!!!</h4>
                </div>
            </div>
            <br />
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Nombre</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Nombre"
                        aria-describedby="inputGroup-sizing-default"
                        defaultValue={name}
                    />
                </InputGroup>
            </div>
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Edad</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Edad"
                        aria-describedby="inputGroup-sizing-default"
                        defaultValue={age}
                    />
                </InputGroup>
            </div>
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Lugar de Nacimeinto</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Lugar de Nacimeinto"
                        aria-describedby="inputGroup-sizing-default"
                        value={birthplace}
                    />
                </InputGroup>
            </div>
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Email</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Email"
                        aria-describedby="inputGroup-sizing-default"
                        value={email}
                    />
                </InputGroup>
            </div>
            <br />
            <Button variant="primary" size="lg" block  onClick={handleInsert}>Salir</Button>
            
        </div>    
    )    
}
