import React, {useState} from 'react'
import Button from 'react-bootstrap/Button';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl';

const name1 = window.$name;
const age1 = window.$age;
const birthplace1 = window.$birthplace;
const email1 = window.$email;

export const Register = () => {
    const [name, setName] = useState('')
    const [age, setAge] = useState('')
    const [birthplace, setBirthplace] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    console.log(process.env.REACT_APP_NOMBRE);
    const handleInsert = async(e) => {
        const resp = await fetch(`http://35.222.249.1:4000/create` , {
            method: 'POST',
            headers:{'Content-Type': 'application/json'},
            body: JSON.stringify({name:name, age: parseInt(age), birthplace: birthplace, email: email, password: password})
        })
        const user_info = await resp.json();
        console.log(user_info);
    }
    
    return (
        <div className="container">
            <div className="row">
                <div className="mx-auto">
                    <h1 className="display-4">Bienvenido a esta App Web</h1>
                </div>
            </div>
            <div className="row">
                <div className="mx-auto">
                    <h3 className="display-8">Si deseas conocer datos sorprendentes, crea tu cuenta</h3>
                </div>
            </div>
            <div className="row">
                <div className="mx-auto">
                    <h4 className="display-8">Ingresa tus datos para continuar</h4>
                </div>
            </div>
            <br />
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Nombre</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Nombre"
                        aria-describedby="inputGroup-sizing-default"
                        onChange={(e)=>setName(e.target.value)}
                    />
                </InputGroup>
            </div>
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Edad</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Edad"
                        aria-describedby="inputGroup-sizing-default"
                        onChange={(e)=>setAge(e.target.value)}
                    />
                </InputGroup>
            </div>
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Lugar de Nacimeinto</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Lugar de Nacimeinto"
                        aria-describedby="inputGroup-sizing-default"
                        onChange={(e)=>setBirthplace(e.target.value)}
                    />
                </InputGroup>
            </div>
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Email</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Email"
                        aria-describedby="inputGroup-sizing-default"
                        onChange={(e)=>setEmail(e.target.value)}
                    />
                </InputGroup>
            </div>
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Password</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Password"
                        aria-describedby="inputGroup-sizing-default"
                        onChange={(e)=>setPassword(e.target.value)}
                    />
                </InputGroup>
            </div>
            <br />
            <Button variant="primary" size="lg" block  onClick={handleInsert}>Ingresar</Button>
            
        </div>    
    )    
}
