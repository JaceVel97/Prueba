import React, {useState} from 'react'
import Button from 'react-bootstrap/Button';
import InputGroup from 'react-bootstrap/InputGroup';
import FormControl from 'react-bootstrap/FormControl';
import Alert from 'react-bootstrap/Alert';

const data_user = {nombre:"", edad:"", lugarnacimiento:"", correo:""}
export const Login = () => {
    const [show, setShow] = useState(false);
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const handleInsert = async(e) => {
        const resp = await fetch(`http://35.222.249.1:4000/login` , {
            method: 'POST',
            headers:{'Content-Type': 'application/json'},
            body: JSON.stringify({email: email, password: password})
        })
        const user_info = await resp.json();
        console.log(user_info.result);
        
        if (user_info.result !== "False"){
            console.log(user_info.result);
            data_user.nombre =  user_info.result.split(',')[0];
            data_user.edad =  user_info.result.split(',')[1];
            data_user.lugarnacimiento =  user_info.result.split(',')[2];
            data_user.correo =  user_info.result.split(',')[3];
            setShow(true)
        }
    }
    
    return (
        
        <div className="container">
            
            <div className="row">
                <div className="mx-auto">
                    <h1 className="display-4">Bienvenido a esta App Web</h1>
                </div>
            </div>
            <div className="row">
                <div className="mx-auto">
                    <h3 className="display-8">Entra y redescubre tu ser</h3>
                </div>
            </div>
            <div className="row">
                <div className="mx-auto">
                    <h4 className="display-8">Ingresa tus datos para continuar</h4>
                </div>
            </div>
            <br />
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Email</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Email"
                        aria-describedby="inputGroup-sizing-default"
                        onChange={(e)=>setEmail(e.target.value)}
                    />
                </InputGroup>
            </div>
            <div className="mx-auto">
                <InputGroup className="mb-3">
                    <InputGroup.Prepend>
                    <InputGroup.Text id="inputGroup-sizing-default">Password</InputGroup.Text>
                    </InputGroup.Prepend>
                    <FormControl
                        aria-label="Password"
                        aria-describedby="inputGroup-sizing-default"
                        onChange={(e)=>setPassword(e.target.value)}
                    />
                </InputGroup>
            </div>
            <br />
            <Button variant="primary" size="lg" block  onClick={handleInsert}>Ingresar</Button>
            <br/>
            <br/>
            <br/>
            <div className="mx-auto">
                <Alert show={show} variant="info">
                    <Alert.Heading>Hola {data_user.nombre} </Alert.Heading>
                    <p>
                    Los datos mas sorprendentes e importantes son tu informacion, por ello en nuestra base de datos tenemos que 
                    tienes {data_user.edad} años, que vives en {data_user.lugarnacimiento}, y por último pero no menos importante
                    que tu correo electrónico es: {data_user.correo}. Éxitos en todo, y siempre sigue adelante.
                    </p>
                    <hr />
                    <div className="d-flex justify-content-end">
                    <Button onClick={() => setShow(false)} variant="outline-dark">
                        Hasta la proxima!
                    </Button>
                    </div>
                </Alert>
            </div>
        </div>    
    )    
}
